<?php

namespace Laravel\Folio\Exceptions;

use Exception;

class PossibleDirectoryTraversal extends Exception
{
    //
}
