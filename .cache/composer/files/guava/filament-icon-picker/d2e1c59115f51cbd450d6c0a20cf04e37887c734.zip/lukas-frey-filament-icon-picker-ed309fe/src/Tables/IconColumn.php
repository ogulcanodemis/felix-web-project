<?php

namespace Guava\FilamentIconPicker\Tables;

use Filament\Tables\Columns\Column;

class IconColumn extends Column
{

    protected string $view = 'filament-icon-picker::tables.icon-column';

}
