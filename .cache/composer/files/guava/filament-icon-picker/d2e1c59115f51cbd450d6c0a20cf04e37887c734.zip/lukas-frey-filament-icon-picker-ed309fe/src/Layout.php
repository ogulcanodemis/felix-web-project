<?php

namespace Guava\FilamentIconPicker;

class Layout
{
    public const FLOATING = 'floating';
    public const ON_TOP = 'on_top';
}
