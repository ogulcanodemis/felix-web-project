module.exports = {
    plugins: {
        "postcss-for": {},
        tailwindcss: {},
        autoprefixer: {},
    }
}
