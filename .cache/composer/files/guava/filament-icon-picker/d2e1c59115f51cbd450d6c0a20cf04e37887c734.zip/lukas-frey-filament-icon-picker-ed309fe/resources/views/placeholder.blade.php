<div class="flex flex-col items-center justify-center" x-data>
	<div class="relative w-full !h-16 flex flex-col items-center justify-center py-2">
		<div class="text-center grow-0 shrink-0 filament-icon-picker-icon-id">No icon selected</div>
	</div>
</div>
