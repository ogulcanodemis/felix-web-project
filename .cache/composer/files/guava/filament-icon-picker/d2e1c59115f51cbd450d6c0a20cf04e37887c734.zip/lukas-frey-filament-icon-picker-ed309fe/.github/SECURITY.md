# Security Policy

If you discover any security related issues, please email office@guava.cz instead of using the issue tracker.
