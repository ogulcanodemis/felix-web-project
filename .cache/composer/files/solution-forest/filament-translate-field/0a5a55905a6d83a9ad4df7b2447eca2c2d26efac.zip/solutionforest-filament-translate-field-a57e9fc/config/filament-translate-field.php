<?php

return [
    'locales' => [],
];