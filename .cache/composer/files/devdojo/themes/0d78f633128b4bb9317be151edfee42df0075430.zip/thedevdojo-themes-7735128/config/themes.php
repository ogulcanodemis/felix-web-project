<?php

return [
	'folder' => resource_path('themes'),
	'publish_assets' => true,
	'create_tables' => true
];