<?php

return [

    'field' => [
        'label' => 'Глобално търсене',
        'placeholder' => 'Търсене...',
    ],

    'no_results_message' => 'Няма намерени резултати.',

];
