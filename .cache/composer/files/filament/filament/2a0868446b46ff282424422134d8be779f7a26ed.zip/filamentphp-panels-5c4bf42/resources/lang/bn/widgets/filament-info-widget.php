<?php

return [

    'actions' => [

        'open_documentation' => [
            'label' => 'ব্যবহার গাইড',
        ],

        'open_github' => [
            'label' => 'গিটহাব',
        ],

    ],

];
