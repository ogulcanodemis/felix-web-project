<?php

return [

    'title' => 'Pagrindinis puslapis',

    'actions' => [

        'filter' => [

            'label' => 'Filtras',

            'modal' => [

                'heading' => 'Filtras',

                'actions' => [

                    'apply' => [

                        'label' => 'Taikyti',

                    ],

                ],

            ],

        ],

    ],
];
