<?php

return [

    'breadcrumb' => 'لیست',

];
