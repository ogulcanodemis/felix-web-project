<?php

return [

    'actions' => [

        'logout' => [
            'label' => 'چوونەدەرەوە',
        ],

    ],

    'welcome' => 'بەخێربێیت',

];
