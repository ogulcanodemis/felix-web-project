<?php

return [

    'field' => [
        'label' => 'সব জায়গায় খুঁজুন',
        'placeholder' => 'খুঁজুন',
    ],

    'no_results_message' => 'খুঁজে পাওয়া যায়নি।',

];
