<?php

return [

    'field' => [
        'label' => 'Գլոբալ որոնում',
        'placeholder' => 'Որոնել',
    ],

    'no_results_message' => 'Որոնման արդյունքներ չեն գտնվել։',

];
