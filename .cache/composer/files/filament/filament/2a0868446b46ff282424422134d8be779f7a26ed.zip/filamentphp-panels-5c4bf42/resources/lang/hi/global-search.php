<?php

return [

    'field' => [
        'label' => 'वैश्विक खोज',
        'placeholder' => 'खोजें',
    ],

    'no_results_message' => 'कोई खोज परिणाम नहीं मिला।',

];
