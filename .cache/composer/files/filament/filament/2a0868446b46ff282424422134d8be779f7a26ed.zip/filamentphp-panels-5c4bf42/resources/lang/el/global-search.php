<?php

return [

    'field' => [
        'label' => 'Γενική αναζήτηση',
        'placeholder' => 'Αναζήτηση',
    ],

    'no_results_message' => 'Δεν βρέθηκαν αποτελέσματα.',

];
