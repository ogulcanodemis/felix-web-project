<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'Spremi promjene',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Spremljeno',
        ],

    ],

];
