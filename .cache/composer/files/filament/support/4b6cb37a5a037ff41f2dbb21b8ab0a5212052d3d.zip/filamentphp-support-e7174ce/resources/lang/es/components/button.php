<?php

return [

    'messages' => [

        'uploading_file' => 'Subiendo archivo...',

    ],

];
