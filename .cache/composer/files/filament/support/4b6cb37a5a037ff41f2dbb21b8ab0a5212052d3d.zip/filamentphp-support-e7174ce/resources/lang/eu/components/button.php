<?php

return [

    'messages' => [

        'uploading_file' => 'Artxiboa igotzen...',

    ],

];
