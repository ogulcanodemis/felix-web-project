<?php

return [

    'actions' => [

        'close' => [
            'label' => 'Fermer',
        ],

    ],

];
