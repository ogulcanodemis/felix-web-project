<?php

return [

    'messages' => [
        'copied' => 'Copié',
    ],

];
