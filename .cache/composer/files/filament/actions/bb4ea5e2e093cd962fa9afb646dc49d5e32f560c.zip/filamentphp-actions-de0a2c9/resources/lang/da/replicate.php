<?php

return [

    'single' => [

        'label' => 'Repliker',

        'modal' => [

            'heading' => 'Repliker :label',

            'actions' => [

                'replicate' => [
                    'label' => 'Repliker',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'Replikeret',
            ],

        ],

    ],

];
