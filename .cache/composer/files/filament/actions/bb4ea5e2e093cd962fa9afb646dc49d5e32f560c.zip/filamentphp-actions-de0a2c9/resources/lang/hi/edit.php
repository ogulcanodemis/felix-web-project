<?php

return [

    'single' => [

        'label' => 'संपादन',

        'modal' => [

            'heading' => ':label संपादित करें',

            'actions' => [

                'save' => [
                    'label' => 'सेव',
                ],

            ],

        ],

        'notifications' => [

            'saved' => [
                'title' => 'सेव हो गया',
            ],

        ],

    ],

];
