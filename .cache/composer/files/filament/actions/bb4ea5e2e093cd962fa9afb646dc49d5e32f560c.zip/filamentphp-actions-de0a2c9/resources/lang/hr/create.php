<?php

return [

    'single' => [

        'label' => 'Dodaj :label',

        'modal' => [

            'heading' => 'Napravi :label',

            'actions' => [

                'create' => [
                    'label' => 'Napravi',
                ],

                'create_another' => [
                    'label' => 'Napravi i napravi drugi',
                ],

            ],

        ],

        'notifications' => [

            'created' => [
                'title' => 'Napravljeno',
            ],

        ],

    ],

];
