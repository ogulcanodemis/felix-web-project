<?php

return [

    'trigger' => [
        'label' => 'Darbības',
    ],

];
