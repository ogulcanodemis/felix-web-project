<?php

return [

    'trigger' => [
        'label' => 'Akce',
    ],

];
