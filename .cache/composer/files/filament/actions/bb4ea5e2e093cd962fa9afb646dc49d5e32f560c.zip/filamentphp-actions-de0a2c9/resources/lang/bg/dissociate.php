<?php

return [

    'single' => [

        'label' => 'Деасоциирай',

        'modal' => [

            'heading' => 'Деасоциирай :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Деасоциирай',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Деасоциирано',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Деасоциирай избраните',

        'modal' => [

            'heading' => 'Деасоциирай избраните :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Деасоциирай',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Деасоциирани',
            ],

        ],

    ],

];
