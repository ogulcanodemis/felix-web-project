<?php

return [

    'single' => [

        'label' => 'Çoxalt',

        'modal' => [

            'heading' => ':label çoxalt',

            'actions' => [

                'replicate' => [
                    'label' => 'Çoxalt',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'Məlumat çoxaldıldı',
            ],

        ],

    ],

];
