<?php

return [

    'single' => [

        'label' => 'Prisilno izbriši',

        'modal' => [

            'heading' => 'Prisilno izbriši :label',

            'actions' => [

                'delete' => [
                    'label' => 'Obriši',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Obrisano',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Prisilno izbriši odabrano',

        'modal' => [

            'heading' => 'Prisilno izbriši odabrano :label',

            'actions' => [

                'delete' => [
                    'label' => 'Obriši',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Obrisano',
            ],

        ],

    ],

];
