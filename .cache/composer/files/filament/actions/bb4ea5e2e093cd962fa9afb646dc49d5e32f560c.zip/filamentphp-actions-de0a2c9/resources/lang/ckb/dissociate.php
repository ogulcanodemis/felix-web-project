<?php

return [

    'single' => [

        'label' => 'جوداکردن',

        'modal' => [

            'heading' => 'جوداکردنی :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'جوداکردن',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'جوداکرا',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'جوداکردنی دیاریکراوەکان',

        'modal' => [

            'heading' => 'جوداکردنی دیاریکراوەکانی :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'جوداکردن',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'جوداکرا',
            ],

        ],

    ],

];
