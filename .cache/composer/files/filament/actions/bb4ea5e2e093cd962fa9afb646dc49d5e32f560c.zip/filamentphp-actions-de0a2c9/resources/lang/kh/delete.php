<?php

return [

    'single' => [

        'label' => 'លុប',

        'modal' => [

            'heading' => 'លុប :label',

            'actions' => [

                'delete' => [
                    'label' => 'លុប',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'បានលុបដោយជោគជ័យ',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'លុបដែលបានជ្រើសរើស',

        'modal' => [

            'heading' => 'លុបដែលបានជ្រើសរើស :label',

            'actions' => [

                'delete' => [
                    'label' => 'លុបដែលបានជ្រើសរើស',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'បានលុបដោយជោគជ័យ',
            ],

        ],

    ],

];
