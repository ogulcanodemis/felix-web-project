<?php

return [

    'single' => [

        'label' => 'Associa',

        'modal' => [

            'heading' => 'Associa :label',

            'fields' => [

                'record_id' => [
                    'label' => 'Record',
                ],

            ],

            'actions' => [

                'associate' => [
                    'label' => 'Associa',
                ],

                'associate_another' => [
                    'label' => 'Associa & associa un altro',
                ],

            ],

        ],

        'notifications' => [

            'associated' => [
                'title' => 'Associato',
            ],

        ],

    ],

];
