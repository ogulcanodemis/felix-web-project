<?php

return [

    'confirmation' => 'ဒီလိုလုပ်ချင်တာသေချာလား',

    'actions' => [

        'cancel' => [
            'label' => 'မလုပ်တော့ပါ',
        ],

        'confirm' => [
            'label' => 'အတည်ပြုသည်',
        ],

        'submit' => [
            'label' => 'နှိပ်ပါ',
        ],

    ],

];
