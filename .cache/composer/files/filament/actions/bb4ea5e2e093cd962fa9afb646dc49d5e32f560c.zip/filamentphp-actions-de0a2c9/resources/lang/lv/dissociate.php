<?php

return [

    'single' => [

        'label' => 'Atdalīt',

        'modal' => [

            'heading' => 'Atdalīt :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Atdalīt',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Atdalīts',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Atdalīt izvēlētos',

        'modal' => [

            'heading' => 'Atdalīt izvēlētos :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Atdalīt',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Atdalīts',
            ],

        ],

    ],

];
