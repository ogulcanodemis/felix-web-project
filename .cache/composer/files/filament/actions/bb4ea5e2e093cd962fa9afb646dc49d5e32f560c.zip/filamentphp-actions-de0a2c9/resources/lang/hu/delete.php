<?php

return [

    'single' => [

        'label' => 'Törlés',

        'modal' => [

            'heading' => ':label törlése',

            'actions' => [

                'delete' => [
                    'label' => 'Törlés',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Törölve',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Kijelöltek törlése',

        'modal' => [

            'heading' => 'Kijelölt :label törlése',

            'actions' => [

                'delete' => [
                    'label' => 'Törlés',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Törölve',
            ],

        ],

    ],

];
