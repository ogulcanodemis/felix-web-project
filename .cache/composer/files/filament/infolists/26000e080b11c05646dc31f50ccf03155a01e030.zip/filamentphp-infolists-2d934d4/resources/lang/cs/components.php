<?php

return [

    'entries' => [

        'text' => [

            'actions' => [
                'collapse_list' => 'Zobrazit o :count méně',
                'expand_list' => 'Zobrazit o :count více',
            ],

            'more_list_items' => 'a 1 další|a :count další| a :count dalších',

        ],

        'key_value' => [

            'columns' => [

                'key' => [
                    'label' => 'Klíč',
                ],

                'value' => [
                    'label' => 'Hodnota',
                ],

            ],

            'placeholder' => 'Žádné záznamy',

        ],

    ],

];
