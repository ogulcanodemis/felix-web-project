<?php

return [

    'text_entry' => [
        'more_list_items' => 'و :count عدد دیگر',
    ],

];
