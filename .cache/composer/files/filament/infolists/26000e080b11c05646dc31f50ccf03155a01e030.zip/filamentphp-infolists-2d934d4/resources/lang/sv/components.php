<?php

return [

    'entries' => [

        'text' => [

            'actions' => [
                'collapse_list' => 'Visa :count färre',
                'expand_list' => 'Visa :count till',
            ],

            'more_list_items' => 'och :count till',

        ],

        'key_value' => [

            'columns' => [

                'key' => [
                    'label' => 'Namn',
                ],

                'value' => [
                    'label' => 'Värde',
                ],

            ],

            'placeholder' => 'Inga objekt',

        ],

    ],

];
