<?php

return [

    'active_locale' => [
        'label' => 'Idioma',
    ],

];
