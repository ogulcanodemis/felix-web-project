<?php

return [

    'active_locale' => [
        'label' => 'Aktiv dil',
    ],

];
