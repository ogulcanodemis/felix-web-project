<?php

return [

    'active_locale' => [
        'label' => 'ទីតាំង',
    ],

];
