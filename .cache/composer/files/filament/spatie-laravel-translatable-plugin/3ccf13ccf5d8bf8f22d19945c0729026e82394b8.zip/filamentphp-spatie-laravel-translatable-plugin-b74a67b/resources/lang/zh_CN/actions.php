<?php

return [

    'active_locale' => [
        'label' => '语言环境',
    ],

];
