<?php

namespace Filament\Pages\Actions;

use Filament\Actions\LocaleSwitcher as BaseLocaleSwitcher;

/**
 * @deprecated Use `\Filament\Actions\LocaleSwitcher` instead.
 */
class LocaleSwitcher extends BaseLocaleSwitcher {}
