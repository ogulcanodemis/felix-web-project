<?php

return [

    'modal' => [

        'heading' => 'التنبيهات',

        'actions' => [

            'clear' => [
                'label' => 'مسح',
            ],

            'mark_all_as_read' => [
                'label' => 'تحديد الكل كمقروء',
            ],

        ],

        'empty' => [
            'heading' => 'لا توجد تنبيهات',
            'description' => 'يرجى التحقق مرة أخرى لاحقاً.',
        ],

    ],

];
