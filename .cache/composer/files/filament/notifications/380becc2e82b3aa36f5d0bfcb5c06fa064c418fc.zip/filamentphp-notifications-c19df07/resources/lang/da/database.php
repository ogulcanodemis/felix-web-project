<?php

return [

    'modal' => [

        'heading' => 'Notifikationer',

        'actions' => [

            'clear' => [
                'label' => 'Ryd',
            ],

            'mark_all_as_read' => [
                'label' => 'Markér alle som læst',
            ],

        ],

        'empty' => [
            'heading' => 'Ingen notifikationer',
            'description' => 'Tjek venligst igen senere',
        ],

    ],

];
