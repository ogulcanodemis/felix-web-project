<?php

namespace Filament\Forms;

class Form extends ComponentContainer {}
