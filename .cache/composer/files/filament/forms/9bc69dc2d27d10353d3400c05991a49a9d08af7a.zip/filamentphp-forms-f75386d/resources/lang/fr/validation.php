<?php

return [

    'distinct' => [
        'must_be_selected' => 'Au moins un champ :attribute doit être sélectionné.',
        'only_one_must_be_selected' => 'Seulement un champ :attribute doit être sélectionné.',
    ],

];
