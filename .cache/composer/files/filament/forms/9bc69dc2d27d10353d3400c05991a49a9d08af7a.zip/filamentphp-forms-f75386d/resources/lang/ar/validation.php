<?php

return [

    'distinct' => [
        'must_be_selected' => 'يجب تحديد حقل :attribute واحد على الأقل.',
        'only_one_must_be_selected' => 'يجب تحديد حقل :attribute واحد فقط.',
    ],

];
