<?php

return [

    'distinct' => [
        'must_be_selected' => 'ต้องเลือกอย่างน้อยหนึ่งฟิลด์ :attribute',
        'only_one_must_be_selected' => 'ต้องเลือกฟิลด์ :attribute เดียวเท่านั้น',
    ],

];
