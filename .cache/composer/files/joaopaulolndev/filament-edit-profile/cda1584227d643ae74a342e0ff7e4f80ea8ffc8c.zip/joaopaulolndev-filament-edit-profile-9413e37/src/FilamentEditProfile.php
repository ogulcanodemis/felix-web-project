<?php

namespace Joaopaulolndev\FilamentEditProfile;

class FilamentEditProfile {}
