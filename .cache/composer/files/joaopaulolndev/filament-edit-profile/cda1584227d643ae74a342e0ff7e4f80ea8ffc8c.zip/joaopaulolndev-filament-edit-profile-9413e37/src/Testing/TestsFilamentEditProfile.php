<?php

namespace Joaopaulolndev\FilamentEditProfile\Testing;

use Livewire\Features\SupportTesting\Testable;

/**
 * @mixin Testable
 */
class TestsFilamentEditProfile
{
    //
}
