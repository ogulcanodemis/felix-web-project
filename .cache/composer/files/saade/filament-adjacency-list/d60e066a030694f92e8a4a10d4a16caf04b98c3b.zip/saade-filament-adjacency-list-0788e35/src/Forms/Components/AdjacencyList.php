<?php

namespace Saade\FilamentAdjacencyList\Forms\Components;

class AdjacencyList extends Component
{
    use Concerns\HasRelationship;
}
