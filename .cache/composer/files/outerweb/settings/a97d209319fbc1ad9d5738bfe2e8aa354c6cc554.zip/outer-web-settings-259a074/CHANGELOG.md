# Changelog

All notable changes to `settings` will be documented in this file.

## 1.0.3 - 2024-03-12

### Added

- Added support for Laravel 11.

## 1.0.2 - 2024-03-04

### Changed

- Improved the installation process by utilizing more of the Spatie package install command.

## 1.0.0 - 2024-02-11

- Initial release
