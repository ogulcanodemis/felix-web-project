<?php

return [
    'form' => [
        'actions' => [
            'save' => 'Save changes',
        ],
    ],
    'page' => [
        'title' => 'Settings',
        'navigation_label' => 'Settings',
    ],
    'notifications' => [
        'saved' => 'Saved',
    ],
];
