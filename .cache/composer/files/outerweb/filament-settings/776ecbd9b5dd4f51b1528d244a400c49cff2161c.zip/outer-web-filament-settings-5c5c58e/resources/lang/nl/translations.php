<?php

return [
    'form' => [
        'actions' => [
            'save' => 'Wijzigingen opslaan',
        ],
    ],
    'page' => [
        'title' => 'Instellingen',
        'navigation_label' => 'Instellingen',
    ],
    'notifications' => [
        'saved' => 'Opgeslagen',
    ],
];
